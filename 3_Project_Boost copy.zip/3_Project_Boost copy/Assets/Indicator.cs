﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Indicator : MonoBehaviour
{
    Renderer myRenderer;
    
    public Rocketplayer2 rocketplayer2;
    

    // Start is called before the first frame update
    void Start()
    {
        myRenderer = GetComponent<Renderer>();
    }

    // Update is called once per frame
    void Update()
    {
        if (rocketplayer2.player2IsIt)
        {
            print("player2isit");
            
        }
    }
}
