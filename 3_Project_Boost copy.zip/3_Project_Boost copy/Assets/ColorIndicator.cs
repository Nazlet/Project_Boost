﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColorIndicator : MonoBehaviour

{
    public Rocketplayer2 rocketplayer2;

    Renderer myRenderer;

    // Start is called before the first frame update
    void Start()
    {
        myRenderer = GetComponent<Renderer>();
        
    }

    // Update is called once per frame
    void Update()
    {
        if (rocketplayer2.player2IsIt)
        {
            myRenderer.material.color = Color.blue;
        }
        else
        {
            myRenderer.material.color = Color.red;
        }
    }
}
